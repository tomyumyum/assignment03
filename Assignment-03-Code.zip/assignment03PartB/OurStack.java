/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: OurStack.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartB;

public class OurStack<T> implements StackInterface<T> {

    public OurStack() {
    }

    @Override
    public void push(T newEntry) {
    }

    @Override
    public T peek() {
    }

    @Override
    public T pop() {
    }

    @Override
    public boolean isEmpty() {
    }

    @Override
    public void clear() {
    }
}